package com.capgemini.fms.service;

import java.util.Map;

import com.capgemini.fms.ExceptionClass.AlreadyGiveFeedback;

public interface IFeedbackService {
	Map<String ,Integer> addFeedbackDetails(String name,int rating,String subject) throws AlreadyGiveFeedback;
	Map<String,Integer> getFeedbackReport();
}
