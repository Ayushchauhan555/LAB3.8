package com.capgemini.fms.bean;

public class Feedback {
	private String teacherName;
	private int rating;
	private String topic;
	
	public Feedback()
	{
		
	}
	public Feedback(String name, String subject, int rating2)
	{
		rating=rating2;
		topic=subject;
		teacherName=name;
	}

	//	GET VALUE OF TEACHERNAME
	public String getTeacherName() 
	{
		return teacherName;
	}
	
//	SET VALUE OF TEACHERNAME
	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}
	
//	GET VALUE OF RATING
	public int getRating() {
		return rating;
	}
	
//	SET VALUE OF RATING
	public void setRating(int rating) {
		this.rating = rating;
	}
	
//	GET VALUE OF TOPIC
	public String getTopic() {
		return topic;
	}
//	SET VALUE OF TOPIC
	public void setTopic(String topic) {
		this.topic = topic;
	}
}
