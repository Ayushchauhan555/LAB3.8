package dao;

import java.util.ArrayList;
import java.util.Map;

import bean.FlatRegistrationDto;
import exception.FlatException;

public interface IFlatRegistrationDao {
	FlatRegistrationDto registerFlatb (FlatRegistrationDto flat) throws FlatException ;
	ArrayList<Integer> getAllOwnerIds() throws FlatException;

	Map<Integer,FlatRegistrationDto>  getRegistrationDetails() throws FlatException;
}
