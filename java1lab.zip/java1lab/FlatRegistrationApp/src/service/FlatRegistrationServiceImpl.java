package service;

import java.util.ArrayList;
import java.util.Map;

import bean.FlatRegistrationDto;
import dao.FlatRegistration;
import dao.IFlatRegistrationDao;
import exception.FlatException;

public class FlatRegistrationServiceImpl implements IFlatRegistrationService {
	IFlatRegistrationDao dao;
	DataValidator validator; 

	public FlatRegistrationServiceImpl()
	{
		dao= new FlatRegistration();
		validator= new DataValidator();
	}

	@Override
	public FlatRegistrationDto registerFlat(FlatRegistrationDto flat) throws FlatException {
		if(!validator.validateFlatType(flat.getFlatType()))
		{
			throw new FlatException("flat type should be either 1 or 2");
		}
		else
		{
		int registrationId= (int) (Math.random()*10000);
		flat.setRegistrationId(registrationId);;
		return dao.registerFlatb(flat);
		}
	}

	@Override
	public ArrayList<Integer> getAllOwnerIds() throws FlatException {
		return dao.getAllOwnerIds();
	}

	@Override
	public Map<Integer, FlatRegistrationDto> getRegistrationDetails() throws FlatException {
		return dao.getRegistrationDetails();
	}

}
