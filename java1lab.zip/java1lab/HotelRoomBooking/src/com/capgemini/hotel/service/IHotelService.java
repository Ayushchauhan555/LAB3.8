package com.capgemini.hotel.service;

import com.capgemini.hotel.bean.CustomerBean;
import com.capgemini.hotel.bean.RoomBooking;

public interface IHotelService {
	int addCustomerDetails(CustomerBean bean);
	RoomBooking getBookingDetails(int CustomerId);
	void roomInfo(String roomType,int roomNo,CustomerBean bean);
	
	String accountIdValidation(String customerId);
	void Validation(String roomNo,String name,String gmail,String roomType);
}
