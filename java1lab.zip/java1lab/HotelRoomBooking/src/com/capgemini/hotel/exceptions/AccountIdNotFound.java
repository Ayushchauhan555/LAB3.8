package com.capgemini.hotel.exceptions;

public class AccountIdNotFound extends RuntimeException{
	public AccountIdNotFound(String message) {
		super(message);
	}
}
