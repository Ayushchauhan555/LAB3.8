package com.cap.pro.service;

public class Validation {
	public boolean validatecategory(String cat)
	{
		
		if(cat.equals("electronics")||cat.equals("paste")||cat.equals("soap")||cat.equals("cosmatics"))
        return true;
        return false;
        }	
	public boolean validatehike(int hike) {
	if(hike>0)
	{
		return true;
	}
	else 
	{
		return false;
	}
	
	}
}
