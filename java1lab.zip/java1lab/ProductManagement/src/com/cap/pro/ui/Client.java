package com.cap.pro.ui;

import java.util.HashMap;
import java.util.Scanner;

import com.cap.pro.dao.ProductDAO;
import com.cap.pro.exception.ProductException;
import com.cap.pro.service.ProductService;

public class Client {
public static void getproductdetails() throws ProductException
	
	{
		System.out.println("The Product Details Are ");
		ProductService service=new ProductService();
		HashMap<String, Integer> productDetails=service.getProductDetails();
		if(productDetails.equals(null)) {
		System.out.println("The map is Empty");
		}
		for(String key:productDetails.keySet())
		{
			
			System.out.println(key+": "+productDetails.get(key) );
		}
		
	}
	

	public static void main(String[] args) {
		ProductService service=new ProductService();
		ProductDAO dao=new ProductDAO();
		
		
		do 
		{
			System.out.println("------------------------------------");
			System.out.println(dao.productDetails);
			System.out.println(dao.salesDetails);
			System.out.println("------------------------------------");
			System.out.println("1.Update Product Price:");
			System.out.println("2.Display Product List");
			System.out.println("3.Exit");
			System.out.println("Select option");
			Scanner sc=new Scanner(System.in);
			
			int option=sc.nextInt();
			switch(option)
			{
			case 1:
				System.out.println("Enter The Product category");
				String pro=sc.next();
				System.out.println("Enter The Hike rate");
				int hike=sc.nextInt();
				
				try {
					service.updateProducts(pro, hike);
				} catch (ProductException e) {
					
				}
				
				
				break;
			case 2:
				try {
					getproductdetails();
				} catch (ProductException e) {
					
				}
				break;
			
			case 3:
				System.out.println("Exit");
				System.exit(0);
				break;
			case 4:
				System.out.println("Invalid choice");
			}	
		}
		while(true);
	}

}
