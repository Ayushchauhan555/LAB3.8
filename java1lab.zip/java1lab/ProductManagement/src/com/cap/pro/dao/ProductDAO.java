package com.cap.pro.dao;

import java.util.HashMap;
import java.util.Map;

import com.cap.pro.exception.ProductException;

public class ProductDAO implements IProductDAO{
	public static Map<String,String> productDetails=new HashMap<String,String>();
	public static HashMap<String, Integer> salesDetails=new HashMap<String,Integer>();
	
	
	static {
		productDetails=new HashMap<>();
		productDetails.put("lux", "soap");
		productDetails.put("colgate", "paste");
		productDetails.put("pears", "soap");
		productDetails.put("sony", "electronics");
		productDetails.put("samsung", "electronics");
		productDetails.put("facepack", "cosmatics");
		productDetails.put("facecream", "cosmatics");
	
		salesDetails=new HashMap<>();
		salesDetails.put("lux", 100);
		salesDetails.put("colgate", 50);
		salesDetails.put("pears", 70);
		salesDetails.put("sony", 10000);
		salesDetails.put("samsung", 23000);
		salesDetails.put("facepack", 100);
		salesDetails.put("facecream", 60);
	}
	@Override
	public int updateProducts(String Category, int hike) throws ProductException {
		for(String key:productDetails.keySet())
		{
			if(productDetails.get(key).equals(Category))
			{
			double price=salesDetails.get(key);
			price=price+((double) hike*price/100);
			salesDetails.put(key, (int)price);
		
			System.out.println("The Updated Price For " +key+" is "+price);
			}
		}
		return 0;
	}

	@Override
	public HashMap<String, Integer> getProductDetails() throws ProductException {
		
		return salesDetails;
	}

	

}
