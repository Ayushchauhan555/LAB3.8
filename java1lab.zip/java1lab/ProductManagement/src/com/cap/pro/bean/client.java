package com.cap.pro.bean;

public class client {
	private String category,ProductName;
	private int price;
	
	
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getProductName() {
		return ProductName;
	}
	public void setProductName(String productName) {
		ProductName = productName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "client [category=" + category + ", ProductName=" + ProductName + ", price=" + price + "]";
	}
	

}
